import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.*;
import javax.servlet.http.*;


public class FirstServlet extends HttpServlet {

public void doGet(HttpServletRequest request, HttpServletResponse response){
                
		try{

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		int n = Integer.parseInt(request.getParameter("username"));
                String p = request.getParameter("password");
                
                LoginBean login = new LoginBean();
                if (login.getUsername().equals("quited")) {
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/index.jsp");
                    rd.forward(request, response);
                } else {
                
                    login.setUsername(request.getParameter("username"));
                    login.setPassword(p);

                    HttpSession session = request.getSession();
                    session.setAttribute("uname",  Integer.toString(n));

                    Statement stmt = null;
                    ResultSet rs = null;
                    String connectionURL = "jdbc:derby://localhost:1527/StudentInfo";

                    try {
                        Connection conn = DriverManager.getConnection(connectionURL, "IS2560", "IS2560");
                        stmt = (Statement) conn.createStatement();
                        rs = stmt.executeQuery("SELECT * FROM student where id=" + n);


                        if ( rs.next() && p.equals(rs.getString("password")) ) {
                            out.print("Welcome " + n);
                            out.print("<br>");
                            out.print("<a href='servlet2'>details</a>");
                            out.print("<br>");
                            out.print("<form action=\"servlet3\" method=\'post\'>\n" + "<input type=\"submit\" value=\"Logout\" />\n" + "</form>");
                            out.close();
                        } else {
                            RequestDispatcher rd = getServletContext().getRequestDispatcher("/index.jsp");
                            rd.forward(request, response);
                            out.println("<script type=\"text/javascript\">");  
                            out.println("alert('Wrong information!');");  
                            out.println("</script>");
                            out.close();

                        }

                        conn.close();
                    } catch (SQLException ex) {
                    System.out.println("Connect failed ! ");
                    }
                }
        
		
                } catch(Exception e){System.out.println(e);}
	}
}




