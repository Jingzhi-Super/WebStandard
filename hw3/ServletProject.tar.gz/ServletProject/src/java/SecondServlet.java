import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class SecondServlet extends HttpServlet {

public void doGet(HttpServletRequest request, HttpServletResponse response){
		try{
                    response.setContentType("text/html");
                    PrintWriter out = response.getWriter();
                    HttpSession session = request.getSession();
                    String n = (String) session.getAttribute("uname");
                    Statement stmt = null;
                    ResultSet rs = null;
                    
                LoginBean login = new LoginBean();
                if (login.getUsername().equals("quited"))  {
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/index.jsp");
                    rd.forward(request, response);
                } else {
                    try {
                        String connectionURL = "jdbc:derby://localhost:1527/StudentInfo";
                        Connection conn = DriverManager.getConnection(connectionURL, "IS2560", "IS2560");
                        stmt = (Statement) conn.createStatement();
                        rs = stmt.executeQuery("SELECT * FROM student where id=" + Integer.parseInt(n));
                        while (rs.next()) {
                        out.print("Math: " + rs.getInt("math"));
                        out.print("<br>");
                        out.print("Physics: " + rs.getInt("Physics"));
                        out.print("<br>");
                        out.print("Chemistry: " + rs.getInt("Chemistry"));
                        out.print("<br>");
                        out.print("history: " + rs.getInt("history"));
                        out.print("<br>");
                        out.print("driving: " + rs.getInt("driving"));
                        out.print("<br>");
                        out.print("<form action=\"servlet3\" method=\'post\'>\n" + "<input type=\"submit\" value=\"Logout\" />\n" + "</form>");
                        out.close();
                        }
                        conn.close();
                    } catch (SQLException ex) {
                    System.out.println("Connect failed ! ");
                    }
                    
                    out.print("<br>");
                    out.print("<form action=\"servlet3\" method=\'post\'>\n" + "<input type=\"submit\" value=\"Logout\" />\n" + "</form>");
                    out.close();
                }
                }catch(Exception e){System.out.println(e);}
	}
	

}
