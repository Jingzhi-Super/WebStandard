import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class database {
    
    public static void main(String[] args) {
        Statement stmt = null;
        ResultSet rs = null;
        String connectionURL = "jdbc:derby://localhost:1527/StudentInfo";
        //ConnectionURL, username and password should be specified in getConnection()
        try {
        Connection conn = DriverManager.getConnection(connectionURL, "IS2560", "IS2560");
        stmt = (Statement) conn.createStatement();
        rs = stmt.executeQuery("SELECT * FROM student where id = 66");
        System.out.println("connect!");
        while (rs.next()) {
            String id = rs.getString("ID");
            String password = rs.getString("password");
            int physics = rs.getInt("math");
            System.out.println("ID: " + id + ", pwd: " + password + physics);
        }
        conn.close();
        } catch (SQLException ex) {
        System.out.println("Connect failed ! ");
        }
    }
}