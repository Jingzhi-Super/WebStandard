var mongoose     = require('mongoose');
var Schema       = mongoose.Schema;
var ProductSchema   = new Schema({
	_id: Number,
    title: String,
    price: Number,
    instock : Boolean,
    photo : String ,
}, { _id: false });
module.exports = mongoose.model('Product', ProductSchema);


